const { Service } = require('node-windows');
const path = require('path');

const svc = new Service({
  name: 'HMS Reception Print Agent',
  description: 'Background service that polls the HMS server for pending print jobs and prints them to the local thermal printer.',
  script: path.join(__dirname, 'index.js'),
  env: [
    {
      name: 'NODE_ENV',
      value: 'production',
    },
  ],
});

svc.on('install', () => {
  console.log('Service installed successfully.');
  svc.start();
});

svc.on('alreadyinstalled', () => {
  console.log('Service is already installed.');
});

svc.on('start', () => {
  console.log('Service started successfully.');
});

svc.on('error', (error) => {
  console.error('Service error:', error);
});

svc.install();
