# Sends a RAW byte stream to a Windows printer via the spooler.
# This works with Epson Advanced Printer Driver virtual ports (ESDPRTxxx)
# because it goes through the Windows print spooler instead of trying to
# open the private virtual-port device directly.
param(
    [Parameter(Mandatory = $true)]
    [string]$PrinterName,

    [Parameter(Mandatory = $true)]
    [string]$FilePath
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path -Path $FilePath)) {
    throw "Raw print data file not found: $FilePath"
}

$bytes = [System.IO.File]::ReadAllBytes($FilePath)

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public class RawPrinterHelper
{
    [DllImport("winspool.drv", CharSet = CharSet.Unicode, ExactSpelling = false, CallingConvention = CallingConvention.StdCall)]
    public static extern bool OpenPrinter(string pPrinterName, out IntPtr phPrinter, IntPtr pDefault);

    [DllImport("winspool.drv", ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool ClosePrinter(IntPtr hPrinter);

    [DllImport("winspool.drv", CharSet = CharSet.Unicode, ExactSpelling = false, CallingConvention = CallingConvention.StdCall)]
    public static extern bool StartDocPrinter(IntPtr hPrinter, int Level, ref DOCINFO pDocInfo);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct DOCINFO
    {
        [MarshalAs(UnmanagedType.LPWStr)] public string pDocName;
        [MarshalAs(UnmanagedType.LPWStr)] public string pOutputFile;
        [MarshalAs(UnmanagedType.LPWStr)] public string pDataType;
    }

    [DllImport("winspool.drv", ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool EndDocPrinter(IntPtr hPrinter);

    [DllImport("winspool.drv", ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool StartPagePrinter(IntPtr hPrinter);

    [DllImport("winspool.drv", ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool EndPagePrinter(IntPtr hPrinter);

    [DllImport("winspool.drv", ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, int dwCount, out int dwWritten);

    public static bool SendBytesToPrinter(string szPrinterName, byte[] pBytes, int dwCount)
    {
        IntPtr hPrinter;
        DOCINFO di = new DOCINFO();
        di.pDocName = "HMS Receipt";
        di.pDataType = "RAW";
        int dwWritten = 0;

        if (!OpenPrinter(szPrinterName, out hPrinter, IntPtr.Zero))
        {
            return false;
        }

        if (StartDocPrinter(hPrinter, 1, ref di))
        {
            if (StartPagePrinter(hPrinter))
            {
                IntPtr pUnmanagedBytes = Marshal.AllocCoTaskMem(dwCount);
                Marshal.Copy(pBytes, 0, pUnmanagedBytes, dwCount);
                bool bSuccess = WritePrinter(hPrinter, pUnmanagedBytes, dwCount, out dwWritten);
                Marshal.FreeCoTaskMem(pUnmanagedBytes);
                EndPagePrinter(hPrinter);
            }
            EndDocPrinter(hPrinter);
        }
        ClosePrinter(hPrinter);

        return dwWritten == dwCount;
    }
}
"@

[bool]$ok = [RawPrinterHelper]::SendBytesToPrinter($PrinterName, $bytes, $bytes.Length)

if (-not $ok)
{
    throw "Failed to send raw print job to '$PrinterName'. Verify the printer name, driver, and that the printer is online."
}
